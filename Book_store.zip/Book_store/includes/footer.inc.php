<div id="footer-wrap">
	<p id="legal">(c) 2020 OurSite. Design by SAN.</p>
	</div>